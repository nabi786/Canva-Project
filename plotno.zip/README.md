# Polotno Studio

**[Launch the application](https://studio.polotno.dev/)**

Design Editor made with [Polotno SDK](https://polotno.dev/). There is nothing super interesting in the repo yet, because all editor features are inside `polotno` package. But soon we will have much more addition features around `polotno` sdk.

### Found a bug? Or want to suggest a feature?

Just create an issues in this repository!

---

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).
